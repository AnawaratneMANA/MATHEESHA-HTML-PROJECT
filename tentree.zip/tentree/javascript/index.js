(function($){
    $(function(){

        $('.sidenav').sidenav();

    }); // end of document ready
})(jQuery);

